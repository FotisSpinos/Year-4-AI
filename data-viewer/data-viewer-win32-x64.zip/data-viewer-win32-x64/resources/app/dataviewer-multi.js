var app = require("electron").remote;
var dialog = app.dialog;
var fs = require("fs");
var convert = require("xml-js");


var globalFitness = null;
var globalDummy = null;
var globalAgent = null;


window.onload = function(){ 
    document.getElementById("openDatasetButton").onclick = () => {

        // Prompt user with an open directoy dialog and store opened directory
        var directory = dialog.showOpenDialogSync({
            properties: ["openDirectory"]
        });

        // Dataset folder location containers
        var fitnessFolder;
        var storedStateFolder;
        var impactFolder;     

        // Get dataset folder locations           
        fs.readdirSync(directory[0]).forEach(file => {
            
            var check = fs.statSync(directory[0] + "\\" + file);
            if (!check.isFile())
            {
                // Run through directories and check if they have dataset folder name
                var dir = directory[0] + "\\" + file;
                if (dir.indexOf("Fitness") > -1)
                {
                    fitnessFolder = directory[0] + "\\" + file;
                }
                else if (dir.indexOf("Stored") > -1)
                {
                    storedStateFolder = directory[0] + "\\" + file;
                }
                else if (dir.indexOf("Impact") > -1)
                {
                    impactFolder = directory[0] + "\\" + file;                    
                }
            }

          });



          DrawButtons(GetDatasetFiles(fitnessFolder,"fitness-"), "fitnessButton");
          DrawButtons(GetDatasetFiles(storedStateFolder,"Dummy Car States"), "dummyButton");
          DrawButtons(GetDatasetFiles(storedStateFolder,"Agent States-"), "agentButton");



    
    };
};


function CallbackFitnessButton (elem){

    if (elem.getAttribute("id") === "fitnessButton")
    {
        DrawFitnessGraph(elem.getAttribute("location"));
    }
    else if (elem.getAttribute("id") === "dummyButton")
    {
        globalDummy = elem.getAttribute("location");

        if (globalAgent != null){
            
            GetAgentDistance(
                GetAgentData(globalAgent),
                GetAgentData(globalDummy)
            );
    
            
           GetAgentDifferance(
                GetAgentData(globalAgent),
                GetAgentData(globalDummy)
            );
        }
    }
    else if (elem.getAttribute("id") === "agentButton") 
    {
        globalAgent= elem.getAttribute("location");

        if (globalDummy != null){
            
            GetAgentDistance(
                GetAgentData(globalAgent),
                GetAgentData(globalDummy)
            );
    
            
           GetAgentDifferance(
                GetAgentData(globalAgent),
                GetAgentData(globalDummy)
            );
        }
    }
    
}

function DrawButtons(datasetFiles, id){

    // Create buttons for each dataset file
    for (i=0; i < datasetFiles.length; i++)
    {
        var ul = document.getElementById("fitnessGroup");

        if (id === "fitnessButton")
        {
            ul = document.getElementById("fitnessGroup");
        }
        else if (id === "dummyButton")
        {
            ul = document.getElementById("dummyGroup");
        }
        else if (id === "agentButton")
        {
            ul = document.getElementById("agentGroup");
        }
        
        var li = document.createElement("li");
        var button = document.createElement("LOAD");

        button.innerHTML = datasetFiles[i].split("\\").pop();
        li.appendChild(button);
        li.setAttribute("id", id);
        li.setAttribute("onclick", "CallbackFitnessButton(this);");
        li.setAttribute("location", datasetFiles[i]);
        li.setAttribute("style", "background-color: #ebebeb; border: 1px solid #40444a; cursor: pointer;");
        ul.appendChild(li);
    }   
    
}


function GetImpactPoints(filename){
    // Grab the XML file then parse it into compact JSON then run it through a JSON parser to store the dataset in JSON.
    console.log("Starting read of file: " + filename);
    var xml = fs.readFileSync(filename);
    var data = convert.xml2json(xml, {compact: true, spaces: 4});    
    var json = JSON.parse(data);


    // Dataset containers
    var impactPos = [,,];

    for(i = 0; i < json.SerializableImpactPoints.impactPoitns.float.length; i++ )
    {
        impactPos.push(json.SerializableImpactPoints.impactPoitns.float[i]._text);
    }

    return impactPos;
}

function GetDatasetFiles(directory, datasetID){

    var datasets = [];

    // Get dataset file locations
    fs.readdirSync(directory).forEach(file => {
            
        var check = fs.statSync(directory + "\\" + file);
        if (check.isFile())
        {            
            var filename = directory + "\\" + file;

            if (file.indexOf(".meta") <= -1)
            {
                if (file.indexOf(datasetID) > -1)
                {
                    // Found a fitness dataset
                    datasets.push(filename);
                }
            }
            
        }

      });

      return datasets;
}



function GetAgentDifferance(agent,dummy){

     // Dataset containers
     var difference = [,,];
     var xDiffPercent = [];
     var yDiffPercent = [];
     var zDiffPercent = [];
     var time = [];


     var xDiff;
     var yDiff;
     var zDiff;
     var diff;
     for(i=2; i < agent[0].length; i++)
     {
         //Math.sqrt( Math.pow( ( x2 - x1 ) ,2) + Math.pow( ( y2 - y1 ) ,2) + Math.pow( ( z2 - z1 ) ,2) );
         xDiff = dummy[0][i][0] - agent[0][i][0];
         yDiff = dummy[0][i][1] - agent[0][i][1];
         zDiff = dummy[0][i][2] - agent[0][i][2];
 
         // Get component difference then add it to it's container
         xDiffPercent.push( xDiff / dummy[0][i][0] );
         yDiffPercent.push( yDiff / dummy[0][i][1] );
         zDiffPercent.push( zDiff / dummy[0][i][2] );
         difference.push([xDiffPercent,yDiffPercent,zDiffPercent]);
 
         // Push time in to container
         time.push(i);   
     }




    DrawGraph3("differanceChart", "line", "X Differance", "Y Differance", "Z Differance", xDiffPercent, yDiffPercent, zDiffPercent , time);
     return difference;
}

function GetAgentDistance(agent, dummy, impactPoints){
      
    // Dataset containers
    var pos = [];
    var time = [];

    // for loop itterator is wrong
    var dist = 0.00001;
    var distSquared = 0.00001;
    var xSquared = 0.00001;
    var ySquared = 0.00001;
    var zSquared = 0.00001;

    console.log("Length of Position data: "+ agent[0].length);

    for(i=2; i < agent[0].length; i++)
    {
        //Math.sqrt( Math.pow( ( x2 - x1 ) ,2) + Math.pow( ( y2 - y1 ) ,2) + Math.pow( ( z2 - z1 ) ,2) );
        xSquared = Math.pow( ( dummy[0][i][0] - agent[0][i][0] ), 2);
        ySquared = Math.pow( ( dummy[0][i][1] - agent[0][i][1] ), 2);
        zSquared = Math.pow( ( dummy[0][i][2] - agent[0][i][2] ), 2);
        distSquared = xSquared + ySquared + zSquared;

        // Convert NaN or Null data to 0 and get distance
        distSquared = distSquared || 0;
        dist = Math.sqrt( distSquared );
        dist = dist || 0;

        // Push data to containers
        pos.push( dist );
        time.push(i);   
    }



    // Draw over time graph with impact point markers
    DrawGraph("distanceChart", "line", "Distance Between Agent And Dummy Over Time", pos, time);

      
}





function GetAgentData(filename){
    
    // Grab the XML file then parse it into compact JSON then run it through a JSON parser to store the dataset in JSON.
    console.log("Starting read of file: " + filename);
    var xml = fs.readFileSync(filename);
    var data = convert.xml2json(xml, {compact: true, spaces: 4});    
    var json = JSON.parse(data);


    // Dataset containers
    var agentPos = [,,];
    var agentRot = [,,];
    var agentVel = [,,];
   

    
    // Fill agent container with dataset position values
    for(i = 0; i < json.SerializableAgentStates.states.AgentState.length; i++)
    {        
        // Pack agent position into 3D array
        agentPos.push([json.SerializableAgentStates.states.AgentState[i].position.x._text,
            json.SerializableAgentStates.states.AgentState[i].position.y._text,
            json.SerializableAgentStates.states.AgentState[i].position.z._text            
        ]);

        // Pack agent rotation into 3D array
        agentRot.push([json.SerializableAgentStates.states.AgentState[i].rotation.x._text,
            json.SerializableAgentStates.states.AgentState[i].rotation.y._text,
            json.SerializableAgentStates.states.AgentState[i].rotation.z._text            
        ]);

        // Pack agent velocity into 3D array
        agentVel.push([json.SerializableAgentStates.states.AgentState[i].velocity.x._text,
            json.SerializableAgentStates.states.AgentState[i].velocity.y._text,
            json.SerializableAgentStates.states.AgentState[i].velocity.z._text            
        ]);
    }

    var agent = [agentPos,agentRot,agentVel];
    return agent;    
}

function DrawFitnessGraph(filename){
    
    // Grab the XML file then parse it into compact JSON then run it through a JSON parser to store the dataset in JSON.
    console.log("Starting read of file: " + filename);
    var xml = fs.readFileSync(filename);
    var data = convert.xml2json(xml, {compact: true, spaces: 4});    
    var json = JSON.parse(data);

    // Dataset containers
    var fitness = [];
    var time = [];
    
    // Fill time container with dataset time stamps
    for(i=0; i < json.SerializableFitnessValues.fitnessValues.float.length; i++)
    {        
        time.push(json.SerializableFitnessValues.captureRate._text * i);
    }

    // Fill fitness container with dataset fitness values
    for(i = 0; i < json.SerializableFitnessValues.fitnessValues.float.length; i++)
    {        
        fitness.push(json.SerializableFitnessValues.fitnessValues.float[i]._text);
    }

    // Draw fitness over time graph
    DrawGraph("fitnessChart", "line", "Fitness Over Time", fitness, time);

}


// Universal chartjs drawer which takes in a chartID(canvas element), a type of graph style, name of the graph, graph data and underneath graph data
function DrawGraph(chartID, type, name ,data, underData){
    
var ctx = document.getElementById(chartID).getContext('2d');
var myChart = new Chart(ctx, {
    type: type,
    data: {
        labels: underData,
        datasets: [{
            label: name,
            data: data,
            backgroundColor: ['rgba(255, 99, 132, 0.2)'],
            borderColor: ['rgba(255, 99, 132, 1)'],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        },
        plugins: {
            zoom: {
                // Container for pan options
                pan: {
                    // Boolean to enable panning
                    enabled: true,             
                    mode: 'xy'                          
         
                },
         
                // Container for zoom options
                zoom: {
                    // Boolean to enable zooming
                    enabled: true,  
                    mode: 'xy',
                      
                    // Speed of zoom via mouse wheel
                    // (percentage of zoom on a wheel event)
                    speed: 0.1,
         
                    // Minimal zoom distance required before actually applying zoom
                    threshold: 2,
         
                    // On category scale, minimal zoom level before actually applying zoom
                    sensitivity: 3,
         
                }
            }
        }
    }
});

}

   










// Universal chartjs drawer which takes in a chartID(canvas element), a type of graph style, name of the graph, graph data and underneath graph data
function DrawGraph3(chartID, type, name1, name2, name3 ,data1, data2, data3, underData){
    
    var ctx = document.getElementById(chartID).getContext('2d');
    var myChart = new Chart(ctx, {
        type: type,
        data: {
            datasets: [{
                label: name1,
                data: data1,
                backgroundColor: ['rgba(255, 0, 0, 0.2)'],
                borderColor: ['rgba(255, 0, 0, 1)'],
            }, {
                label: name2,
                data: data2,
                backgroundColor: ['rgba(0, 255, 0, 0.2)'],
                 borderColor: ['rgba(0, 255, 0, 1)'],
    
                type: type
            }, {
                label: name3,
                data: data3,
                backgroundColor: ['rgba(0, 0, 255, 0.2)'],
                borderColor: ['rgba(0, 0, 255, 1)'],
    
                type: type
            }],
            labels: underData
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            },
            elements: {
                point: {
                    radius: 0
                }
            },
            plugins: {
                zoom: {
                    // Container for pan options
                    pan: {
                        // Boolean to enable panning
                        enabled: true,             
                        mode: 'xy'                          
             
                    },
             
                    // Container for zoom options
                    zoom: {
                        // Boolean to enable zooming
                        enabled: true,  
                        mode: 'xy',
                          
                        // Speed of zoom via mouse wheel
                        // (percentage of zoom on a wheel event)
                        speed: 0.1,
             
                        // Minimal zoom distance required before actually applying zoom
                        threshold: 2,
             
                        // On category scale, minimal zoom level before actually applying zoom
                        sensitivity: 3,
             
                    }
                }
            }
        }
    });
    
    }






