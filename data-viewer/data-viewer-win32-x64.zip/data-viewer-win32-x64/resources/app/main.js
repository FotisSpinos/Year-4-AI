const electron = require("electron");
const url = require("url");
const path = require("path");
const fs = require("fs");

const {app, BrowserWindow, Menu, dialog} = electron;

let mainWindow;
let datasetWindow;
let openDatasetWindow;


// Listen for app to be ready
app.on("ready", function(){

    // Create new window
    mainWindow = new BrowserWindow({
        width: 1280,
        height: 720,
        title: "ML-Agents Data Viewer",
        webPreferences: {
            nodeIntegration: true
        }
    });

    // Load html into window
    mainWindow.loadURL(url.format({
        pathname: path.join(__dirname, "mainWindow.html"),
        protocol: "file:",
        slashes: true
    }));

    // Quit app on close
    mainWindow.on("closed", function(){
        app.quit();
    });

    // Build menu from template
    const mainMenu = Menu.buildFromTemplate(mainMenuTemplate);
    // Insert the menu
    Menu.setApplicationMenu(mainMenu);

});


// Handle add data file window
function createOpenDatasetWindow(){
    // Create new window
    openDatasetWindow = new BrowserWindow({
        width: 320,
        height: 640,
        title: "Open data file",
        webPreferences: {
            nodeIntegration: true
        }
    });

    // Load html into window
    openDatasetWindow.loadURL(url.format({
        pathname: path.join(__dirname, "openDatasetWindow.html"),
        protocol: "file:",
        slashes: true
    })); 

    // Clean up open prompt when its closed
    openDatasetWindow.on("close", function(){
       datasetWindow = null;
    });

    openDatasetWindow.setMenu(null);
}




// Handle add data file window
function createDatasetWindow(){
     // Create new window
     datasetWindow = new BrowserWindow({
         width: 320,
         height: 640,
         title: "Open data file",
         webPreferences: {
             nodeIntegration: true
         }
     });

     // Load html into window
     datasetWindow.loadURL(url.format({
         pathname: path.join(__dirname, "datasetWindow.html"),
         protocol: "file:",
         slashes: true
     })); 

     // Clean up open prompt when its closed
     datasetWindow.on("close", function(){
        datasetWindow = null;
     });

     datasetWindow.setMenu(null);
}





// Create main menu template
const mainMenuTemplate = [
    {
        label: "Load Dataset",
        submenu: [
            {
                label: "Latest dataset",
                accelerator: process.platform == "darwin" ? "Command+L" : "Ctrl+L",
                click(){
                    createDatasetWindow();
                }
            },
            {
                label: "Open dataset",
                accelerator: process.platform == "darwin" ? "Command+O" : "Ctrl+O",
                click(){
                    createOpenDatasetWindow();
                }
            },
            {
                label: "Quit",
                click(){
                    app.quit();
                }
            }
        ]
    }
];






// Developer tools 
/*
if (process.env.NODE_ENV !== "production"){
    mainMenuTemplate.push({
        label: "Developer Tools",
        submenu:[
            {
                label: "Toggle Developer Tools",
                accelerator: process.platform == "darwin" ? "Command+I" : "Ctrl+I",
                click(item, focusedWindow){
                    focusedWindow.toggleDevTools();
                }
            }
        ]

    });
}
*/
// A painful programming experience brought to you by: caleb :(